import pusher3

def main():
    pusher3.eml_pusher()
